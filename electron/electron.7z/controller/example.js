const { Controller } = require('ee-core');
const Services = require('ee-core/services');

/**
 * 示例控制器
 * @class
 */
class ExampleController extends Controller {

  constructor(ctx) {
    super(ctx);
  }

  /**
   * 所有方法接收两个参数
   * @param args 前端传的参数
   * @param event - ipc通信时才有值。详情见：控制器文档
   */

  /**
   * test
   */
  async test (args, event) {

    // 前端参数
    const params = args;

    // 调用service
    const result = await Services.get('example').test('electron');

    // 主动向前端发请求
    // channel 前端ipc.on()，监听的路由
    const channel = "controller.example.something"
    // IpcMainInvokeEvent
    event.reply(channel, {age:21})
    // IpcMainEvent
    event.sender.send(`${channel}`, data)

    // 返回数据
    const data = {}
    return data;
  }
}  
