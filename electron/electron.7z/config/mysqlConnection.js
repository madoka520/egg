const mysql = require('mysql');

const connection = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'mengtuyuan',
    database:'mengtu_yuan'
})

connection.connect((error) => {
    if (error) {
        console.error('Error connecting to MySQL:', error);
    } else {
        console.log('Connected to MySQL server');
    }
});

connection.query('SELECT * FROM anji_drum',(error,result,fields)=>{
    if (error){
        console.log('error')
    }else {
        console.log(result)
    }
})