const { Service } = require('ee-core');
const Services = require('ee-core/services');

/**
 * 示例服务
 * @class
 */
class ExampleService extends Service {

  constructor(ctx) {
    super(ctx);
  }

  /**
   * test
   */
  async test (args) {
    let obj = {
      status:'ok',
      params: args
    }

    // 调用其它service
    Services.get('framework').test('egg');

    return obj;
  }
}

ExampleService.toString = () => '[class ExampleService]';
module.exports = ExampleService;
