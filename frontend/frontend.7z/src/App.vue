<template>
  <div>
    <router-view style="margin-left: -180px;"/>
  </div>
</template>

<script setup>
document.getElementById('loadingPage').remove()

</script>
<style lang="less">


</style>
