<template>
  <div>
    aaa
  </div>
</template>
<script>
import { ipcApiRoute } from '@/api/main';
import { ipc } from '@/utils/ipcRenderer';
export default {
  data(){
    return{

    }
  },
  mounted() {
    console.log(ipc)
    ipc.invoke(ipcApiRoute.test,{name:'张三'}).then(r=>{
      console.log(r);
    })
  },
  methods:{

  },

}

</script>
<style scoped lang="less">

</style>