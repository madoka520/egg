/**
 * 基础路由
 * @type { *[] }
 */

const constantRouterMap = [
  {
    path: '/',
    name: 'login',
    redirect: { name: 'ExampleHelloIndex' },
    children: [
      {
        path: '/example',
        name: 'ExampleHelloIndex',
        component: () => import('@/views/login/LoginView.vue')
      },
      {
        path: '/test',
        name: 'test',
        component:()=>import('@/views/TestView.vue')
      }
    ]
  },
]

export default constantRouterMap